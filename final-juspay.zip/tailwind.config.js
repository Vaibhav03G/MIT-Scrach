module.exports = {
  darkMode: "class",
  purge: ["./src/**/*.js"],
  variants: {},
  theme: {
    extend: {
      zIndex: {
        '1000': '1000',
      },
    },
  },
  plugins: [],
};

